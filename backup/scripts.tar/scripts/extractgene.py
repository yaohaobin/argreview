import pandas as pd
from Bio import SeqIO
import sys

querygene = sys.argv[1]

queryid = set()

index = pd.read_csv(sys.argv[2],header=None,sep='\t')
for idx,row in index.iterrows():
    if float(row[11]) >=2000 and str(row[1]).lower().find(querygene)>=0:
        queryid.add(row[0])


seqfile = open(sys.argv[3],'r')
for record in SeqIO.parse(seqfile,'fasta'):
    if record.id in queryid:
        print('>'+record.description)
        print(record.seq) 

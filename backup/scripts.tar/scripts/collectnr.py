import sys
tabfile = open(sys.argv[1],'r')
queryset = set()
for line in tabfile:
    line = line.strip()
    info = line.split('\t')
    if not info[0] in queryset:
        print(info[0])
        queryset.add(info[0])

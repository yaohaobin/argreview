import sys
import pandas as pd
import os 
for dirname,pathnames,filenames in os.walk(sys.argv[1]):
    for filename in filenames:
        if filename.find('RR')<0 or filename.find('txt')<0 or filename.find('.orf')>=0:
            continue
        
        result = pd.read_csv(dirname+'/'+filename,header=0,sep='\t')
        
        for idx,row in result.iterrows():
            coverage = float(row['Percentage Length of Reference Sequence'])
            if coverage >= int(sys.argv[2]):
                print(filename.split('_')[0]+'\t'+row['ORF_ID']+'\t'+str(row['Best_Hit_ARO'])+'\t'+str(row['Best_Identities'])+'\t'+str(row['Pass_Bitscore'])+'\t'+str(row['Best_Hit_Bitscore'])+'\t'+str(coverage)+'\t'+str(row['ARO']),len(row['Predicted_Protein'])*1.0/len(row['CARD_Protein_Sequence']))
            

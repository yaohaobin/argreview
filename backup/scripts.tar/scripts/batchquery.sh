for i in `cat $1`
do
  name=$(basename $i)
  sampleid=${name%_*}
  
  ./query.sh $2 $i $sampleid &  

  

  
  #python resfinder.py -i $i -o result/$sampleid/$2 -p ../argproject/resfinder/ -d $2 -t 0.9 -l 0.60 
  
done
  

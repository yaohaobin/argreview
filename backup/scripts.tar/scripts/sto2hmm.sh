for i in `cat $1`
do
  input=${i%.sto}
  hmmbuild --cpu 16 -o $input.log  $input.hmm $input.sto
done 

import pandas as pd
import sys


besthit = {}

problem = pd.read_csv(sys.argv[1],sep='\t',header=None)


for idx,row in problem.iterrows():
   querytype = row[0].split('|')[2]
   hittype = row[1].split('|')[2]
   if not row[0] in besthit.keys():
       besthit[row[0]] = row[1]
       if querytype ==  hittype:
           num = 1



print(len(besthit))

from Bio.Blast import NCBIXML
import sys


xmlfile = open(sys.argv[1],'r')
xmlresult = NCBIXML.parse(xmlfile)
matchlist = []
for record in xmlresult:
    if len(record.alignments) > 0:
            for alignment in record.alignments:

                for hsp in alignment.hsps:

                    if float(hsp.bits) >= 2000 and record.query.find('MexF')>=0:
                       
                        print('>'+record.query+'\t'+alignment.accession+'\t'+str(record.query_length)+'\t'+str(len(hsp.query))+'\t'+str(len(hsp.sbjct))+'\t'+str(hsp.score)+'\t'+str(hsp.bits)+'\t'+str(hsp.expect)+'\t'+str(hsp.identities))
                        #print(hsp.match)

import pandas as pd
import sys

result = open(sys.argv[1],'r')
param = pd.read_csv(sys.argv[2],sep='\t',header=None)
aro2param = {}

for idx,row in param.iterrows():
    aroid = 'ARO:'+str(int(row[0]))
    aro2param[aroid] = float(row[1])

for line in result:
    line = line.strip()
    info = line.split('\t')
    aroid = info[1].split('|')[2]
    if float(info[11]) >= aro2param[aroid]:
        print(line)
    

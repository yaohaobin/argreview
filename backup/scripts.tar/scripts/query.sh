for i in `cat $1`
do
  dbdir=$(basename $i)
  dbname=${dbdir%.fsa}
  input=$2
  sampleid=$3
  #mkdir /nas1/hbyao_1/argproject/resfinder/result/$sampleid
  mkdir /nas1/hbyao_1/argproject/resfinder/result/$sampleid/$i
  python resfinder.py -i $input -o result/$sampleid/$i -p ../argproject/resfinder/ -d $dbname -t 0.9 -l 0.40  
done

for i in `cat $1`
do
  name=$(basename $i)
  blastp -db sargblast -query $2/$i -out sargresult/$name.xml -outfmt 5 -evalue 1e-10 &
done

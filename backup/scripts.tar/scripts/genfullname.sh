while read line
do
  echo $1/$line
done < $2

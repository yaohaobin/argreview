def ambiguity(aroid,predata):
   
    for preid,data in predata.items():
        for point in data:
            if preid

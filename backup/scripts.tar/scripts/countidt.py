import sys
import os
query = {}
queryhit = open(sys.argv[1],'r')
for line in queryhit:
    line = line.strip()
    info = line.split('\t')
    frags = info[0].split('#')
    query[frags[0]+'#'+frags[3]] = info[1]

for dirname,path,filenames in os.walk(sys.argv[2]):
    for filename in filenames:
        if filename.find('tab')<0 or filename.find('faa')<0 or filename.find('RR')<0 or filename.find('amr')>=0:
            continue
        resultname = dirname+'/'+ filename
        result = open(resultname,'r')
        
        #outfile = open(outfilename,'w')
        
        fileid = filename.split('_')[0]
        ctgmap={}
        for line in result:
            line = line.strip()
            if line[0] == '#':
                continue
            info = line.split('\t')

            orfid = info[0] +'#'+ fileid
   
            aroid = info[1].split('|')[2].split(':')[1]

            if orfid in query.keys() and query[orfid] == aroid:
                print(orfid+'\t'+line)

            
            


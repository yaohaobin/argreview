
# function for node traversal 
def traverse(node): 
    while fully_expanded(node): 
        node = best_uct(node) 
          
    # in case no children are present / node is terminal  
    return pick_univisted(node.children) or node  
  
# function for the result of the simulation 
def rollout(node): 
    while non_terminal(node): 
        node = rollout_policy(node) 
    return result(node)  
  
# function for randomly selecting a child node 
def rollout_policy(node): 
    return pick_random(node.children) 
  
# function for backpropagation 
def backpropagate(node, result): 
    if is_root(node) return
    node.stats = update_stats(node, result)  
    backpropagate(node.parent) 
  
# function for selecting the best child 
# node with highest number of visits 
def best_child(node): 
    pick child with highest number of visits 

def gengrid(data,unitx,unity):
	grid = []
    for preid,aroid,x,y in data:
        gridx = x/unitx
        gridy = y/unity
        grid.append(preid,aroid,x,y)

    grid = sorted(grid,lambda d:d[2])
    return grid

class config:
	def __init__(self,a,b):
		self.along = []
	    self.division = [a,b]
	def update_plus_slope(self,nexta):
		newalong = []
		a,b = self.division
		for x,y in self.along:
			
			ey = nexta *x + b
			while y<ey:
				y += 1
            newalong.append([x,y])
        return newalong
    def update_plus_intercept(self,nextb):
        newalong = []
		a,b = self.division
		for x,y in self.along:
			
			ey = a *x + nextb
			while y<ey:
				y += 1
            newalong.append([x,y])
        return newalong

    def update_minus_slope(self,nexta):
    	newalong = []
		a,b = self.division
		for x,y in self.along:
			
			ey = nexta *x + b
			while y>ey:
				y -= 1
            newalong.append([x,y+1])
        return newalong





#for division line y = ax + b, we randomly modify a or b slightly
 def neighbor(config,a,b,stepa,stepb,L0):
    randset = genrandom()
    nexta = a
    nextb = b

    
    for da in randset:
    	nexta += da*stepa
        
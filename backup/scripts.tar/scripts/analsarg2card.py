import pandas as pd
import sys

sarg2card = {}

sarg2cardfile = pd.read_csv(sys.argv[1],header=None,sep='\t')
for idx,row in sarg2cardfile.iterrows():
    if not row[0] in sarg2card.keys():
        sarg2card[row[0]] = row[1].split('|')[2]+','+str(row[2])+','+str(row[10])+','+str(row[11])
    


for k,v in sarg2card.items():
    print(k+'\t'+v)

mv sarg-category//puromycin__puromycin\ resistance\ protein.fa sarg-category//puromycin__puromycin_resistance_protein.fa
mv sarg-category//aminoglycoside__streptomycin\ resistance\ protein.fa sarg-category//aminoglycoside__streptomycin_resistance_protein.fa
mv sarg-category//unclassified__antibiotic\ resistance\ rRNA\ adenine\ methyltransferase.fa sarg-category//unclassified__antibiotic_resistance_rRNA_adenine_methyltransferase.fa
mv sarg-category//unclassified__cystathionine\ beta-lyase\ patB.fa sarg-category//unclassified__cystathionine_beta-lyase_patB.fa
mv sarg-category//beta-lactam__class\ C\ beta-lactamase.fa sarg-category//beta-lactam__class_C_beta-lactamase.fa
mv sarg-category//unclassified__thiostrepton\ resistance\ methylase\ tsnR.fa sarg-category//unclassified__thiostrepton_resistance_methylase_tsnR.fa
mv sarg-category//unclassified__mycinamicin-resistance\ protein\ myrB.fa sarg-category//unclassified__mycinamicin-resistance_protein_myrB.fa
mv sarg-category//unclassified__16S\ rRNA\ methylase.fa sarg-category//unclassified__16S_rRNA_methylase.fa
mv sarg-category//aminoglycoside__tunicamycin\ resistance\ protein.fa sarg-category//aminoglycoside__tunicamycin_resistance_protein.fa
mv sarg-category//chloramphenicol__chloramphenicol\ and\ florfenicol\ resistance\ gene.fa sarg-category//chloramphenicol__chloramphenicol_and_florfenicol_resistance_gene.fa
mv sarg-category//beta-lactam__class\ B\ beta-lactamase.fa sarg-category//beta-lactam__class_B_beta-lactamase.fa
mv sarg-category//aminoglycoside__streptothricin\ acetyltransferase.fa sarg-category//aminoglycoside__streptothricin_acetyltransferase.fa
mv sarg-category//rifamycin__rifampin\ resistance\ protein.fa sarg-category//rifamycin__rifampin_resistance_protein.fa
mv sarg-category//beta-lactam__class\ A\ beta-lactamase.fa sarg-category//beta-lactam__class_A_beta-lactamase.fa
mv sarg-category//bleomycin__bleomycin\ resistance\ protein.fa sarg-category//bleomycin__bleomycin_resistance_protein.fa
mv sarg-category//aminoglycoside__viomycin\ phosphotransferase.fa sarg-category//aminoglycoside__viomycin_phosphotransferase.fa
mv sarg-category//unclassified__transcriptional\ regulatory\ protein\ CpxR\ cpxR.fa sarg-category//unclassified__transcriptional_regulatory_protein_CpxR_cpxR.fa
mv sarg-category//multidrug__EmrB-QacA\ family\ major\ facilitator\ transporter.fa sarg-category//multidrug__EmrB-QacA_family_major_facilitator_transporter.fa
mv sarg-category//rifamycin__ADP-ribosylating\ transferase_arr.fa sarg-category//rifamycin__ADP-ribosylating_transferase_arr.fa
mv sarg-category//unclassified__cAMP-regulatory\ protein.fa sarg-category//unclassified__cAMP-regulatory_protein.fa
mv sarg-category//unclassified__two-component\ system_response\ regulator\ EvgA.fa sarg-category//unclassified__two-component_system_response_regulator_EvgA.fa
mv sarg-category//kasugamycin__kasugamycin\ resistance\ protein\ ksgA.fa sarg-category//kasugamycin__kasugamycin_resistance_protein_ksgA.fa
mv sarg-category//aminoglycoside__bifunctional\ aminoglycoside\ N-acetyltransferase\ and\ aminoglycoside\ phosphotransferase.fa sarg-category//aminoglycoside__bifunctional_aminoglycoside_N-acetyltransferase_and_aminoglycoside_phosphotransferase.fa
mv sarg-category//unclassified__truncated\ putative\ response\ regulator\ ArlR.fa sarg-category//unclassified__truncated_putative_response_regulator_ArlR.fa
mv sarg-category//chloramphenicol__chloramphenicol\ exporter.fa sarg-category//chloramphenicol__chloramphenicol_exporter.fa
mv sarg-category//beta-lactam__cephalosporinase\ DHA-2.fa sarg-category//beta-lactam__cephalosporinase_DHA-2.fa
mv sarg-category//unclassified__bacterial\ regulatory\ protein\ LuxR.fa sarg-category//unclassified__bacterial_regulatory_protein_LuxR.fa
mv sarg-category//beta-lactam__class\ D\ beta-lactamase.fa sarg-category//beta-lactam__class_D_beta-lactamase.fa
mv sarg-category//chloramphenicol__cat_chloramphenicol\ acetyltransferase.fa sarg-category//chloramphenicol__cat_chloramphenicol_acetyltransferase.fa
mv sarg-category//unclassified__DNA-binding\ transcriptional\ regulator\ gadX.fa sarg-category//unclassified__DNA-binding_transcriptional_regulator_gadX.fa
mv sarg-category//chloramphenicol__chloramphenicol\ and\ florfenicol\ exporter.fa sarg-category//chloramphenicol__chloramphenicol_and_florfenicol_exporter.fa
mv sarg-category//unclassified__cob(I)alamin\ adenolsyltransferase.fa sarg-category//unclassified__cob(I)alamin_adenolsyltransferase.fa
mv sarg-category//rifamycin__rifampin\ monooxygenase.fa sarg-category//rifamycin__rifampin_monooxygenase.fa

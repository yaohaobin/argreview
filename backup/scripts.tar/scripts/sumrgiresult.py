import sys
import os
import numpy as np
import pysam as py




def checkread(read):
    if read.is_secondary or read.is_supplementary or read.is_unmapped:
        return False
    return True

def genalignname(basename):
    
    info = basename.split('_') 
    sampleid = info[0]
    return sampleid+'.sam.bam'
    
aro={}
category={}
totalmap={}
everymap={}


index = open(sys.argv[2],'r')
for line in index:
    line = line.strip()
    info = line.split('\t')
    category[info[0]] = info[2]

aro2acc = open(sys.argv[3],'r')
for line in aro2acc:
    line = line.strip()
    info = line.split('\t')
    aro[info[0]]=info[5]




for dirname,path,filenames in os.walk(sys.argv[1]):
    for filename in filenames:
        if  filename.find('txt')<0 or filename.find('RR')<0 or filename.find('orf')>=0:
            continue
        resultname = dirname+'/'+filename
        result = open(resultname,'r')
        
        align=py.AlignmentFile(sys.argv[4]+'/'+genalignname(filename)) 
        next(result)
        singlemap={}
        #hitresult = open(resultname+'.orf','w')
        
        for line in result:
            line = line.strip()
            info = line.split('\t')
            #if(len(info[16])<25):
                #continue
            #gid = info[1].split('|'i)
            

            ctginfo=info[0].split('#')
            
            orfid = ctginfo[0].split('_')
            ctgid = orfid[0]+'_'+orfid[1]
            if float(info[6]) > float(info[7]):
                continue
           
            cover = align.count_coverage(ctgid,int(ctginfo[1])-1,int(ctginfo[2]),read_callback=checkread)
            coverage = np.mean(cover)*4

            gid = aro['ARO:'+info[10]]
            #gname = category[gid]
            gname=info[10]

            #hitresult.write(ctginfo[0]+'\t'+info[10]+'\n')
            if gname in singlemap.keys():
                singlemap[gname]+=coverage
            else:
                singlemap[gname]=coverage
        #hitresult.close()
        everymap[filename] = singlemap
        for k,v in singlemap.items():
            if k in totalmap.keys():
                totalmap[k] += v
            else:
                totalmap[k] = v


totallist = []
for k,v in totalmap.items():
    totallist.append((k,v))

totallist = sorted(totallist,reverse=True,key=lambda d:d[1])
showmap = {}
i = 0
#print(len(totallist))
for k,v in totallist:
    if i<30:
        showmap[k] = v
    i=i+1


output = ''
for k in showmap.keys():
    output+=k+'\t'
print(output.rstrip('\t'))
idx = 1
output = ''
for samplename in everymap.keys():
    output+=str(idx)+'\t'
    idx += 1
print(output.rstrip('\t'))
'''

for name,singlemap in everymap.items():
    output = ''
    for k in showmap.keys():
        if k in singlemap.keys():
            output+=str(singlemap[k])+'\t'
        else:
            output+='0\t'
    output = output.rstrip('\t')
    print(output)
                  
'''


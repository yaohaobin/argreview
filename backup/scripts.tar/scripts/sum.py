import pandas as pd
import sys

sp2num = {}


def readanswer(filename):
    #print(filename)
    answer = open(filename,'r')
    
    for line in answer:
        line = line.strip()
        row = line.split('\t')
        sp = row[0]
        global sp2num
        if sp in sp2num.keys():
            sp2num[sp] += 1
        else:
            sp2num[sp] = 1






filelist = open(sys.argv[1],'r')
for line in filelist:
    line = line.strip()
    readanswer(line)

sp2numlist = list(sp2num.items())

sp2numlist = sorted(sp2numlist,key=lambda d:d[1],reverse=True)
#print(sp2numlist)

spstat = open(sys.argv[2],'r')
for line in spstat:
    line = line.strip()
    info = line.split(' ')
    sp = info[0]
    
    if sp in sp2num.keys():
        print(info[3])   

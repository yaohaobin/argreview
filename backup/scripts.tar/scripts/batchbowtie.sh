while read line
do 
  echo $line
  #echo "$(line) --fast --threads 16"
  bowtie2 $line 

done < $1

import pandas as pd
import sys

result = pd.read_csv(sys.argv[1],header=None,sep='\t')

for idx,row in 

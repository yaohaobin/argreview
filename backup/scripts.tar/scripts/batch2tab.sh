for i in `cat $1`
do
  name=$(basename $i)
  
  diamond view -a $i -o sarg/$name.tab -f 6 -p 48
done



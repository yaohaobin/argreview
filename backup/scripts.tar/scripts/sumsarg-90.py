import sys
import os
import pandas as pd
card90 = {}
queryresult = pd.read_csv(sys.argv[2],header=None,sep='\t')
for idx,row in queryresult.iterrows():
    card90[row[0].strip()] = 1

for dirname,pathnames,filenames in os.walk(sys.argv[1]):
        
    for filename in filenames:
        if filename.find('RR')>=0 and filename.find('faa')>=0 and filename.find('tab')>=0:
            resultname = dirname+'/'+filename
            #print(resultname)
            sargresult = open(resultname,'r')
            processed = {}
            for line in sargresult:
                line = line.strip()
                info = line.split('\t')
                orfid = info[0]
                if not orfid in processed.keys():
                    processed[orfid] = 1
                    if not info[1] in card90.keys():
                        print(line+'\t'+filename.split('_')[0])

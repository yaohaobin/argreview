import sys
import os

for dirname,pathname,filenames in os.walk(sys.argv[1]):
    for filename in filenames:
        if filename.find('.sto')>=0:
            continue
        if filename.find(' ')>=0:
            newname = filename.replace(' ','\ ')
            outname = newname.replace('\ ','_')
            print('mv '+dirname+'/'+newname+' '+dirname+'/'+outname)

import os
import sys
from Bio import SeqIO

def extractseq(ctgmap,seqfilename,outfilename):
    seqfile = open(seqfilename,'r')
    seqdata = {}
    #outfile = open(outfilename,'w')
    for record in SeqIO.parse(seqfile,'fasta'):
        seqdata[record.id] = str(record.seq)
    for key in ctgmap.keys():
        print('>'+key[0]+'#'+str(key[1])+'#'+str(key[2])+'#'+outfilename)
        print(seqdata[key[0]][key[1]:key[2]]) 



for dirname,path,filenames in os.walk(sys.argv[1]):
    for filename in filenames:
        if filename.find('tab')<0 or filename.find('ERR')<0:
            continue
        resultname = dirname+'/'+ filename
        result = open(resultname,'r')
        outfilename = sys.argv[3]+'/'+filename.replace('faa.hmm.tab','hit.fa')
        #outfile = open(outfilename,'w')
        seqfilename = sys.argv[2] + '/'+filename.replace('.faa.hmm.tab','')
        ctgmap={}
        for line in result:
            line = line.strip()
            if line[0] == '#':
                continue
            info = line.split(' ')
            info = list(filter(lambda x: x!='',info))

            orfid = info[0].split('_')
            ctgid = orfid[0]+'_'+orfid[1]
            #cover = align.count_coverage(ctgid,int(info[19])-1,int(info[21]),read_callback=checkread)
            start = int(info[19])-1
            end = int(info[21])

            ctgkey = (ctgid,start,end)
            
            if not ctgkey in ctgmap.keys():
                ctgmap[ctgkey] = 1
                
        extractseq(ctgmap,seqfilename,outfilename)

from Bio import SeqIO
import sys
seqfile = open(sys.argv[1],'r')
inputid = sys.argv[2]
inputname = sys.argv[3]
idx = 0
for record in SeqIO.parse(seqfile,'fasta'):
    
    newid = str(idx)+'|'+'ARO_Name:'+inputname+'|'+inputid
    print('>'+newid)
    print(str(record.seq))
    idx += 1

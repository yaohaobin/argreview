import pandas as pd
import sys
from sklearn import svm
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import RobustScaler
import numpy as np
import threading


class processtax(threading.Thread):
    def __init__(self,aroid):
        threading.Thread.__init__(self)
        self.aroid = aroid
    def run(self):
        global pre2data
        #global pre2tax
        data = pre2data[self.aroid]
        '''
        tax2num = {}
        for preid,x,y in data:
            if not preid in pre2tax.keys():
                continue
            tax = pre2tax[preid]
            if tax in tax2num.keys():
                tax2num[tax] += 1
            else:
                tax2num[tax] = 1
        if len(tax2num) == 0:
            return
        taxlist = sorted(list( tax2num.items() ),key=lambda d:d[1],reverse=True)
        '''

        cnum = calC(data,self.aroid)
        threadLock.acquire()
        print(self.aroid,len(data),cnum,cnum*1.0/len(data))
        #print(self.aroid,taxlist[0][0],taxlist[0][1],len(data),taxlist[0][1]*1.0/len(data))
        threadLock.release()

def readtax(filename):
    taxresult = open(filename,'r')
    global pre2tax
    for line in taxresult:
        line = line.strip()
        row = line.split('\t')
        if len(row[1].split('|')) < 3 :
            continue
        preid = row[1].split('|')[0].split(':')[1]
        pre2tax[preid] = row[2]
        
def readbest(filename):
    preresult = open(filename,'r')
    #global pre2type
    global pre2data
    for line in preresult:
        line = line.strip()
        row = line.split('\t')
        if len(row[0].split('|')) < 3 :
            continue
        preid = row[0].split('|')[0].split(':')[1]

        aroid = row[1].split('|')[2]

        pretype =  row[0].split('|')[2]
        pre2type[preid] = pretype
        
        prename = row[0].split('|')[1].split(':')[1]
        #pre2name[preid] = prename
        y = row[11]
        x = row[2]
        
        if aroid in pre2data.keys():
            pre2data[aroid].append([preid,x,y])
        else:
            pre2data[aroid] = [[preid,x,y]]

def calC(databest,aroid):
    num = 0
    global pre2type
    for preid,x,y in databest:
        if pre2type[preid] == aroid:
            num += 1
    return num*1.0

pre2type = {}
pre2data  = {}
pre2tax = {}
readbest(sys.argv[1])
#readtax(sys.argv[2])
threadLock = threading.Lock()
querylist = list(pre2data.keys())
i = 0
threadnum = 36

print(len(querylist))
while i<len(querylist):
    threads = []
    for j in range(threadnum):
        if i >= len(querylist):
            break
        if True:
            task = processtax(querylist[i])
            task.start()
            threads.append(task)
        i= i+1

    for task in threads:
        task.join()

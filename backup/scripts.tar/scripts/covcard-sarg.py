import sys

cutfile = open(sys.argv[2],'r')
aro2cut = {}
for line in cutfile:
    line = line.strip()
    info = line.split('\t')
    aro2cut[info[0]] = float(info[1])





pfam2card={}
num=0
cardresult = open(sys.argv[1],'r')
for line in cardresult:
    line = line.strip()
    info = line.split('\t')
    score = float(info[len(info)-1])
    aronum = info[0].split('|')[2].split(':')[1]
    if aro2cut[aronum] <= score:
        num += 1
        if info[1] in pfam2card.keys():
            if score >= pfam2card[info[1]][1]:
                pfam2card[info[1]] = (info[0],score)
            
        else:
            pfam2card[info[1]] = (info[0],score)



sarg2card = {}
sarg2cardfile = open(sys.argv[4],'r')
for line in sarg2cardfile:
    line = line.strip()
    info = line.split('\t')
    if not info[0] in sarg2card.keys():
        sarg2card[info[0]] = info[1]

sargresult = open(sys.argv[3],'r')



for line in sargresult:
    line = line.strip()
    info = line.split('\t')
    pfamid = info[1]
    sargid = info[0]
    if pfamid in pfam2card.keys() and sargid in sarg2card.keys():
        if pfam2card[pfamid][0] == sarg2card[sargid]:
            print(line+'\t'+pfam2card[pfamid][0]+'\t'+str(pfam2card[pfamid][1]))

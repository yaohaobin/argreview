import sys
tabfile = open(sys.argv[1],'r')
idbest = {}
idbestname = {}
 
for line in tabfile:
    if line[0] == '#':
        continue
   
    line = line.strip()
    info = line.split(' ')
    info = list(filter(lambda x: x!='',info))
    
    score = float(info[5])
    gid = info[0]
    if gid in idbest.keys():
        if idbest[gid] < score:
            idbest[gid] = score
            idbestname[gid] = info[2]
    else:
        idbest[gid] = score
        idbestname[gid] = info[2]

name_vec = {}

for k,v in idbest.items():
    hmm = idbestname[k]
    if hmm in name_vec.keys():
        name_vec[hmm].append(k)
    else:
        name_vec[hmm] = [k]
    print(k,v,idbestname[k])


'''
for hmm,vec in name_vec.items():
    outstr = hmm+'\t'+str(len(vec))
    for gid in vec:
        outstr=outstr+'\t'+gid
    print(outstr)

'''

import pandas as pd
import sys

sarg2cardfile = pd.read_csv(sys.argv[1],header=None,sep='\t')


for idx,row in sarg2cardfile.iterrows():
    identity = float(row[1].split(',')[1])
    if identity < 50:
        print(row[0]+'\t'+row[1])

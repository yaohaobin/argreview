import sys
from Bio import SeqIO

reshit= {}

res = open(sys.argv[1],'r')
for line in res:
    line = line.strip()
    info = line.split('\t')
    reshit[info[5].split(' ')[0]+'\t'+info[len(info)-1]]  = info[0]

rgihit = {}

rgi = open(sys.argv[2],'r')
for line in rgi:
    line = line.strip()
    info = line.split('\t')
    orfinfo = info[0].split('_')
    ctgid = orfinfo[0]+'_'+orfinfo[1]
    rgihit[ctgid+'\t'+info[2].split('_')[0]] = info[1]


#for hit in rgihit.keys():
    #if not hit in reshit.keys():
        #print(hit+'\t'+reshit[hit])


amrhit = {}
fafile = open(sys.argv[3],'r')
for record in SeqIO.parse(fafile,'fasta'):
    ctgid = record.id.split('#')[0]
    info = record.id.split('/')
    sampleid = info[len(info)-1].split('_')[0]
    amrhit[ctgid+'\t'+sampleid] = 1


for hit in rgihit.keys():
    print(hit)




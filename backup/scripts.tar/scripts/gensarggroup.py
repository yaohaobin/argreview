import sys
import ast
from Bio import SeqIO

id2seq = {}

seqfile = open(sys.argv[2],'r')
for record in SeqIO.parse(seqfile,'fasta'):
    id2seq[record.id] = str(record.seq)

structure=open(sys.argv[1],'r')
next(structure)

categorymap = {}
singlenum =0
for line in structure:
    line = line.strip()
    info = line.split('\t')
    category = info[0] 
    namelist = ast.literal_eval(info[1])
    categorymap[category] = namelist
    if len(namelist) == 1:
        singlenum += 1
    '''
    output=open(sys.argv[3]+'/'+category+'.fa','w')
        
    for pid in namelist:
        output.write('>'+pid+'\n')
        output.write(id2seq[pid]+'\n')
    output.close()
    '''     
print(singlenum)
    

import pandas as pd
import sys
import threading

class sort_predata (threading.Thread):
    def __init__(self,aroid):
        threading.Thread.__init__(self)
        self.aroid = aroid
    def run(self):
        threadLock.acquire()
        predata = aro_pre[aroid]
        print(len(predata))
        threadLock.release()



prevalence = pd.read_csv(sys.argv[1],header=None,sep='\t')
aroidx = pd.read_csv(sys.argv[2],header=0,sep='\t')


aroidlist = []
id2name = {}

for idx,row in aroidx.iterrows():
    aroidlist.append(row['ARO Accession']) 
    id2name[row['ARO Accession']] = row['ARO Name']

aro_pre = {}

nullnum = 0
for idx,row in prevalence.iterrows():
    aroid = row[1].split('|')[2]
    
    preinfo = row[0].split('|')
    if len(preinfo) < 3:
        nullnum += 1
        continue
    preid = preinfo[2]
    pid = float(row[2])
    score = float(row[10])
    point = (pid,score)
    if aroid in aro_pre.keys():
        predata = aro_pre[aroid]
        if preid in predata.keys():
            predata[preid].append(point)
        else:
            predata[preid] = [point]
    else:
        predata = {}
        predata[preid] = [point]
        aro_pre[aroid] = predata

print(len(aro_pre),nullnum)
threadLock = threading.Lock()

threads = []

for i in range(len(id2name)):
     aroid = aroidlist[i]
     if aroid in aro_pre.keys():
         print(aroid)
         arothread = sort_predata(aroid)
         threads.append(arothread)
         arothread.start()


for t in threads:
     t.join()

print('exit')



import sys

currentquery = ''

currentpd = 101

currentline = ''
result = open(sys.argv[1],'r')
for line in result:
    line = line.strip()
    info = line.split('\t')
    pd = float(info[2])
    query = info[0]
    if query != currentquery:
        if len(currentquery)>0:
            print(line)
        currentquery = query
        currentpd = pd
        currentline = line
    else:
        if pd > currentpd:
            currentquery = query
            currentpd = pd
            currentline = line


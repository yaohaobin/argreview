from Bio import SeqIO
import sys

queryset = set()

query = open(sys.argv[1],'r')
for line in query:
    line = line.strip()
    queryset.add(line)

seqfile = open(sys.argv[2],'r')
for record in SeqIO.parse(seqfile,'fasta'):
    if record.id in queryset:
        print('>'+record.id)
        print(str(record.seq))


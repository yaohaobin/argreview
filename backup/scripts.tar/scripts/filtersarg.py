import sys
import pandas as pd

result = open(sys.argv[1],'r')
lines = []
for line in result:
    line = line.strip()
    lines.append(line)


valid = set()
for line in lines:
    info = line.split('\t')
    if info[1].find('3000804')>=0 and float(info[11]) >= 1500:
        valid.add(info[0])

for line in lines:
    info = line.split('\t')
    if info[0] in valid:
        print(line)

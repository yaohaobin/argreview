import sys

arodetail = {}

result = open(sys.argv[1],'r')
for line in result:
    line = line.strip()
    info = line.split('\t')
    preid = info[0]
    num = int(info[1])
    if num>0:
        for i in range(num):
            inaroid = info[2+i*2]
            innum = int(info[3+i*2]) 

            if inaroid in arodetail.keys():
                if preid in arodetail[inaroid].keys():
                    arodetail[inaroid][preid] += innum
                else:
                    arodetail[inaroid][preid] = innum
            else:
                arodetail[inaroid] = {}
                arodetail[inaroid][preid] = innum

for aroid, data in arodetail.items():
    outstr=''
    outstr+= aroid+'\t'+str(len(data))
    for preid,innum in data.items():
         outstr+='\t'+preid+'\t'+str(innum)

    print(outstr)

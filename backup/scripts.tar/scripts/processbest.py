import pandas as pd

import sys
def readidx(filename):
    index = pd.read_csv(filename,header=None,sep='\t')
    for idx,row in index.iterrows():
        aro2name[row[0]] = row[5]

def readbest(filename):
    hit={}
    result = open(filename,'r')
    for line in result:
        line = line.strip()
        row = line.split('\t')
        if len(row[0].split('|')) < 3 :
            continue
        preid = row[0].split('|')[0].split(':')[1]
        aroid = row[1].split('|')[2]

        pretype =  row[0].split('|')[2]

        hit[preid] = aroid

    
    return hit

def readall(filename):
    tabresult = open(filename,'r')
    data = []

    problem = {}
    for line in tabresult:
        line = line.strip()
        row = line.split('\t')
        if len(row[0].split('|')) < 3 :
            continue
            
        preid = row[0].split('|')[0].split(':')[1]
        aroid = row[1].split('|')[2]

        pretype =  row[0].split('|')[2]
        #pre2type[preid] = pretype
        prename = row[0].split('|')[1].split(':')[1]
        #pre2name[preid] = prename
        y = row[11]
        x = row[2]
    
        if preid in besthit.keys():
            if pretype != besthit[preid]:
                if besthit[preid] in problem.keys():
                    problem[besthit[preid]] += 1
                else:
                    problem[besthit[preid]] = 1
    for k,v in problem.items():
        if v>=50:
            print(k,v)
    
aro2name = {}
readidx(sys.argv[3])
besthit = readbest(sys.argv[1])
readall(sys.argv[2])
    

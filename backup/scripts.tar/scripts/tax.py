import sys
import pandas as pd

def fetchpre(filename):
    query = set()
    prealign = open(sys.argv[1],'r')
    for line in prealign:
        line = line.strip()
        info = line.split('\t')
        preid = info[0]
        query.add(preid)


    return query


queryid = fetchpre(sys.argv[1])

result = open(sys.argv[2],'r')
for line in result:
    line = line.strip()
    info = line.split('\t')
    if info[0] != 'C':
        continue
    preid = info[1]
    if preid in queryid:
        print(line)

for i in `cat $1`
do
  dbname=$(basename $i)
  echo $dbname
  diamond makedb -d db/$dbname --in $i
done

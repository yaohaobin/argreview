import sys
import pandas as pd

result = pd.read_csv(sys.argv[1],header=None,sep='\t')
num = 0
total = 0
yesnum = 0
for idx,row in result.iterrows():
    if row[0].find('MexF')<0:
        total += 1
        x = float(row[2])
        y = float(row[11])
        y_ = x*22.711 - 162.68
        if y>=y_:
            
            #print(x,y)
            if y>=1300:
                print(x,y,row[0])
                num = num + 1
    



import sys
import pandas as pd
from Bio import SeqIO
import ast

index = pd.read_csv(sys.argv[1],header=0,sep='\t')
query = sys.argv[2]
queryset = set()
for idx,row in index.iterrows():
    if row[0].find(query)>=0:
        namelist = list(ast.literal_eval(row[1]))
        for name in namelist:
            queryset.add(name)



seqfile = open(sys.argv[3],'r')
for record in SeqIO.parse(seqfile,'fasta'):
    if record.id in queryset:
        print('>'+record.id)
        print(record.seq)

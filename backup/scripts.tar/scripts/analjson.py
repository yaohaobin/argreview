import json
import sys
def readjson(filename):
    jsfile = open(filename,'r')
    js = json.load(jsfile)

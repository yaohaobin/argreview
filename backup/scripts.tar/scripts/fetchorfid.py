from Bio import SeqIO
import sys
query = set()
orfid=open(sys.argv[1],'r')
for line in orfid:
    line = line.strip()
    query.add(line)


seqfile = open(sys.argv[2],'r')
for record in SeqIO.parse(seqfile,'fasta'):
    if record.id in query:
        print('>'+record.id)
        print(str(record.seq))


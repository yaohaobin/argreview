import sys
from Bio import SeqIO

querygene = sys.argv[1]

seqfile = open(sys.argv[2],'r')
for record in SeqIO.parse(seqfile,'fasta'):
    if record.id.find(querygene)>=0:
        print('>'+record.description)
        print(record.seq)

from Bio import SeqIO
import sys
import os

inputlist = open(sys.argv[1],'r')
num = 0
sumlen = float(0)
for line in inputlist:
    line = line.strip()
    seqfile = open(line,'r')
    for record in SeqIO.parse(seqfile,'fastq'):
        num += 1
        sumlen+= len(str(record.seq))
 
    seqfile.close()

print(num,sumlen,sumlen/num)

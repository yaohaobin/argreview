import scipy.stats as ss
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
import pandas as pd
import threading
import sys
import numpy as np

def recolor(data,cut,totaldata):
    svr = SVR(kernel='linear',epsilon=cut*1.0/10)
    yesx=[]
    yesy=[]
    allx = []
    ally = []
    predata = []
    problemup = {}
    problemdown = {}
    for preid,aroid,x,y in data:
        #prename = row[0].split('|')[1].lower().split(':')[1]
        #pretype = row[0].split('|')[2]
        #preid = row[0].split('|')[0].split(':')[1]
    
        #pre2type[preid] = pretype
        pretype = pre2type[preid]
        #cut = aro2cut[aroid]
    #predata.append([preid,x,y])
    
        if y>94:
            allx.append(x)
            ally.append(y)
            predata.append([preid,aroid,x,y])
            if pretype == aroid:
                yesx.append(x)
                yesy.append(y)

    if len(yesx) == 0:
        return(problemup,problemdown,0,0,2)
    X = np.array(yesx).reshape(-1,1)
    Y = np.array(yesy).flatten()
    svr.fit(X,Y)  

    scorex = []
    scorey = []
    for preid,aroid,x,y in totaldata:
       if y>94:
           scorex.append(x)
           scorey.append(y)
    scoreX = np.array(scorex).reshape(-1,1)        
    scoreY = np.array(scorey).flatten()       

    #print(svr.coef_)
    #lr.fit(X,Y)
    score = svr.score(scoreX,scoreY)
    slope = svr.coef_.tolist()[0][0]
    intercept = svr.intercept_.tolist()[0]
    allX = np.array(allx).reshape(-1,1)

    spredictY = svr.predict(scoreX).tolist()
    #predictY = lr.predict(allX).tolist()
    
    idx = 0
    for preid,aroid,x,y in totaldata:
        if y>=spredictY[idx]:
            if pre2type[preid] != aroid:
                #print(preid,pre2name[preid],x,y)
                #if x>=90 and y >=250:
                    #problemid.add(preid)
            #pre2type[preid] = aroid
               problemup[preid] = aroid
        elif pre2type[preid] == aroid:
            #pre2type[preid] = 'na'
            problemdown[preid] = aroid
        idx += 1
    return (problemup,problemdown,slope,intercept,score)

def readdata(df):
    data = []
    for idx,row in df.iterrows():
        if len(row[0].split('|')) < 3 :
            continue
        preid = row[0].split('|')[0].split(':')[1]
        aroid = row[1].split('|')[2]
    
        pretype =  row[0].split('|')[2]
        pre2type[preid] = pretype
        prename = row[0].split('|')[1].split(':')[1]
        pre2name[preid] = prename
        y = row[2]
        x = row[11]
        
        data.append([preid,aroid,x,y])
    return data



class compute (threading.Thread):
    def __init__(self,aroid):
        threading.Thread.__init__(self)
        self.aroid = aroid
    def run(self):
        #threadLock.acquire()

        

        predata = aro_pre[self.aroid]
        totaldata =aro_total[self.aroid]        
        threshold = aro2param[self.aroid]
        (problemup,problemdown,slope,intercept,score) = recolor(predata,threshold,totaldata)
        threadLock.acquire()
        print(self.aroid,len(problemup),len(problemdown),slope,intercept,score)
        threadLock.release()

def readtab(filename):
    nullnum = 0
    prevalence = pd.read_csv(filename,header=None,sep='\t')
    pre = {}
    for idx,row in prevalence.iterrows():
        aroid = row[1].split('|')[2]
        preid = row[0].split('|')[0].split(':')[1]

        preinfo = row[0].split('|')
        if len(preinfo) < 3:
            nullnum += 1
            continue
    #preid = preinfo[2]
        pre2type[preid] = row[0].split('|')[2]
        pid = float(row[2])

        score = float(row[11])

        point = (pid,score)
        if aroid in pre.keys():
            predata = pre[aroid]
            predata.append([preid,aroid,score,pid])
        
        else:
            predata = []
            predata.append([preid,aroid,score,pid])
            pre[aroid] = predata
        
    return pre


aroidx = pd.read_csv(sys.argv[2],header=0,sep='\t')

aroparam = pd.read_csv(sys.argv[3],header=None,sep='\t')
aro2param = {}
for idx,row in aroparam.iterrows():
    aro2param['ARO:'+str(int(row[0])).strip()] = row[1]

pre2type = {}
aroidlist = []
id2name = {}
aroinother = {}
for idx,row in aroidx.iterrows():
    aroidlist.append(row['ARO Accession'])
    id2name[row['ARO Accession']] = row['ARO Name']



aro_pre = readtab(sys.argv[1])
aro_total = readtab(sys.argv[4])
'''
nullnum = 0
for idx,row in prevalence.iterrows():
    aroid = row[1].split('|')[2]
    preid = row[0].split('|')[0].split(':')[1]
 
    preinfo = row[0].split('|')
    if len(preinfo) < 3:
        nullnum += 1
        continue
    #preid = preinfo[2]
    pre2type[preid] = row[0].split('|')[2]
    pid = float(row[2])

    score = float(row[11])

    point = (pid,score)
    if aroid in aro_pre.keys():
        predata = aro_pre[aroid]
        predata.append([preid,aroid,pid,score])
        
        if preid in predata.keys():
            predata[preid].append(point)
        else:
            predata[preid] = [point]
        
    else:
        predata = []
        predata.append([preid,aroid,pid,score])
        aro_pre[aroid] = predata


'''




threadLock = threading.Lock()



threadnum = 12
i = 0

while i<len(id2name):
     threads  = []
     for j in range(threadnum):
         aroid = aroidlist[i]
         if aroid in aro_pre.keys():
             #print(aroid)

             arothread = compute(aroid)
             arothread.start()
             threads.append(arothread)


         i += 1
         if i>= len(id2name):
             break


     for t in threads:
         t.join()


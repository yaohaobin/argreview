import sys
import pandas as pd
inother = open(sys.argv[2],'r')
modelresult = pd.read_csv(sys.argv[1],header=None,sep=' ')
suminother = open(sys.argv[3],'r')
model2tp = {}
model2all = {}
aro2num = {}
aro2sum = {}

for idx,row in modelresult.iterrows():
    model2tp[row[0]] = row[2]
    model2all[row[0]] = row[1]




for line in inother:
    line = line.strip()
    info = line.split('\t')
    aroid = info[0]
    num = int(info[1])
    inratio = 0.0
    if  num > 0:
        for i in range(num):
            inaroid = info[2+i*2]
            innum = int(info[3+i*2])
             
            
                
            
            if inaroid in model2all.keys():
                inratio += float(innum)/model2all[inaroid]
    if inratio>0:
        print(aroid,inratio/num)
            #aro2num[aroid][inaroid] = innum 
            

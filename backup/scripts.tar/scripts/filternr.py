import sys

result = open(sys.argv[1],'r')
queryset = set()
for line in result:
    line = line.strip()
    info = line.split('\t')
    if not info[0] in queryset:
        print(line)
        queryset.add(info[0])

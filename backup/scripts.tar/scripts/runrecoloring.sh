python computesvc.py adef.tab ../adeffamily50.txt 12 adefleft.tab aro_index.csv

from Bio import SeqIO
import sys
import os

inputlist = open(sys.argv[1],'r')
num = 0
sumlen = float(0)
lenlist = []
for line in inputlist:
    line = line.strip()
    seqfile = open(line,'r')
    for record in SeqIO.parse(seqfile,'fasta'):
        num += 1
        seqlen = len(str(record.seq))
        sumlen+= seqlen
        lenlist.append(seqlen)
    seqfile.close()
      
lenlist.sort()
lenlist.reverse()
n50len = sumlen/2.0
n50 = 0
valuesum = 0
for value in lenlist:
    valuesum += value
    if valuesum >= n50len:
        n50=value  
print(num,sumlen,sumlen/num,n50)

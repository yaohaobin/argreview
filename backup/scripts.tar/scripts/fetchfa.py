from Bio import SeqIO
import sys
import pandas as pd


queryset = set()
for i in range(2,len(sys.argv)):
    queryset.add(sys.argv[i])
seqfile = open(sys.argv[1],'r')
for record in SeqIO.parse(seqfile,'fasta'):
    if record.id in queryset:
        print('>'+record.id)
        print(str(record.seq))

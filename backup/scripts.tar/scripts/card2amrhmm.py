import sys

card2amrhmm = 

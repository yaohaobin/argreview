import pandas as pd
import sys


queryset = set()
result = open(sys.argv[1],'r')
for line in result:
    line = line.strip()
    info = line.split('\t')
    if not info[0] in queryset:
        print(line)
        queryset.add(info[0])



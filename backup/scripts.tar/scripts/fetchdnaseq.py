import pandas as pd
from Bio import SeqIO
import sys

seqdata = {}
seqfile = open(sys.argv[2],'r')
for record in SeqIO.parse(seqfile,'fasta'):
    seqdata[record.id] = str(record.seq)


result = pd.read_csv(sys.argv[1],header=None,sep='\t')
for idx,row in result.iterrows():
    info = row[1].split('#')
    orfid = info[0].strip().split('_')
    ctgid = orfid[0]+'_'+orfid[1]
    

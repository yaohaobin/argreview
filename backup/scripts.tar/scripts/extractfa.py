import sys
import os
from Bio import SeqIO

for dirname,path,filenames in os.walk(sys.argv[1]):
    for filename in filenames:
        fafile = open(dirname+'/'+filename,'r')
        for record in SeqIO.parse(fafile,'fasta'):
            print('>'+record.description)
            print(str(record.seq))
            

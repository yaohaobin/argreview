for i in `cat $1`
do
  megahit -r $i -o assemble/$i
done 

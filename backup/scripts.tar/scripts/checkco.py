import pandas as pd

import sys

aroidx = pd.read_csv(sys.argv[1],header=0,sep='\t')
aro2name = {}
for idx,row in aroidx.iterrows():
    aro2name[row[0]] = row[5]


bestdata=pd.read_csv(sys.argv[2],header=None,sep=',')
for idx,row in aroidx.iterrows():
    

import sys
from Bio import SearchIO
import ast
category={}
category_  = {}
categoryfile = open(sys.argv[3],'r')
next(categoryfile)
for line in categoryfile:
    line = line.strip()
    info = line.split('\t')
    namelist = ast.literal_eval(info[1])
    category_[info[0]] = len(namelist)
    for name in namelist:
       
        category[name] = info[0]

firsthit = {}
sarg2amr = open(sys.argv[4],'r')
for line in sarg2amr:
    line = line.strip()
    if line[0]=='#':
        continue
    info = line.split(' ')
    info = list(filter(lambda x:x!='',info))
    score = float(info[5])
    if info[0] in firsthit.keys():
        if score > firsthit[info[0]][1]:
            firsthit[info[0]] = (info[2],score)
    else:
        firsthit[info[0]] = (info[2],score)






hmmfile = open(sys.argv[1],'r')

amrhit={}
seq2hmm = {}
for line in hmmfile:
    line = line.strip()
    if line[0]=='#':
        continue
    info = line.split(' ')
    info = list(filter(lambda x:x!='',info))
    if not (info[0],info[2]) in amrhit.keys():
        amrhit[(info[0],info[2])] = float(info[5])
        if info[0] in seq2hmm.keys():
            seq2hmm[info[0]].append(info[2])
        else:
            seq2hmm[info[0]] = [info[2]]


sargfile = open(sys.argv[2],'r')
pool={}


hitsum = 0
misssum = 0
for line in sargfile:
    line = line.strip()
    info = line.split('\t')
    if info[1] in seq2hmm.keys():
        for hmm in seq2hmm[info[1]]:
            if not info[0] in firsthit.keys() or hmm != firsthit[info[0]][0]:
                continue   
            print(info[0],info[1],hmm,amrhit[(info[1],hmm)],info[11]) 
            categoryhit = category[info[0]]
            if categoryhit in pool.keys():
                pool[categoryhit] += 1
            else:
                pool[categoryhit] = 1
                hitsum += category_[categoryhit]

for k,l in category_.items():
    if not k in pool.keys():
        print(k,l)

print(hitsum)

import sys
import os
import pandas as pd
orfhits = {}
queryresult = pd.read_csv(sys.argv[2],header=None,sep='\t')
for idx,row in queryresult.iterrows():
    orfhits[row[0].strip()] = 1

for dirname,pathnames,filenames in os.walk(sys.argv[1]):
        
    for filename in filenames:
        if filename.find('RR')>=0 and filename.find('faa')>=0 and filename.find('tab')>=0:
            resultname = dirname+'/'+filename
            #print(resultname)
            sargresult = open(resultname,'r')
            for line in sargresult:
                line = line.strip()
                info = line.split('\t')
                if info[0] in orfhits.keys():
                    print(line+'\t'+filename.split('_')[0])

import sys
from Bio import SeqIO

query = sys.argv[2]
seqfile = open(sys.argv[1],'r')
for record in SeqIO.parse(seqfile,'fasta'):
    if record.id.lower().find(query)>=0:
        print('>'+record.id)
        print(record.seq) 

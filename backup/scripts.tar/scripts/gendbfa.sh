for i in `cat $1`
do
  python $2 $i >> $3
done

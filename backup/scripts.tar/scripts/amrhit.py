import sys
from Bio import SeqIO

amrhit = {}
fafile = open(sys.argv[1],'r')
for record in SeqIO.parse(fafile,'fasta'):
    ctgid = record.id.split('#')[0]
    info = record.id.split('/')
    sampleid = info[len(info)-1].split('_')[0]
    amrhit[ctgid+'\t'+sampleid] = 1



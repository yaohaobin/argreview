for i in `cat $1`
do
  if [ ! -f "$i.sto" ] 
  then
      clustalo -i $i -o $i.sto --outfmt st --threads 16
  fi
done

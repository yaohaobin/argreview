import sys
import pandas as pd

result = pd.read_csv(sys.argv[1],sep=' ',header=None)
for idx,row in result.iterrows():
    if row[5] < 1 and row[5]>=0.6:
        print(row[0]+'\t'+str(row[3])+'\t'+str(row[4])+'\t'+str(row[5]))

 

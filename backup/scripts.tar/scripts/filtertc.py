import sys
tsvfile = open(sys.argv[2],'r')
cutoff = {}

for line in tsvfile:
    line = line.strip()
    info = line.split('\t')
    cutoff[info[1]] = float(info[2])


tabfile = open(sys.argv[1],'r')
for line in tabfile:
    line = line.strip()
    if line[0] == '#':
        continue
    info = line.split(' ')
    info = list(filter(lambda x:x!='',info))
    if cutoff[info[2]] <= float(info[5]):
        print(info[0]+'\t'+info[2]+'\t'+info[3]+'\t'+info[4]+'\t'+info[5])
   
  


import pandas as pd
import sys


aro2threshold = {}
aroparam = pd.read_csv(sys.argv[2],header=None,sep='\t')
for idx,row in aroparam.iterrows():
    aro2threshold['ARO:'+str(int(row[0]))] = float(row[1])

sarg2card = pd.read_csv(sys.argv[1],header=None,sep='\t')

for idx,row in sarg2card.iterrows():
    if float(row[11]) >= aro2threshold[row[1].split('|')[2]]:
        print(row[0],row[1],aro2threshold[row[1].split('|')[2]],row[11])

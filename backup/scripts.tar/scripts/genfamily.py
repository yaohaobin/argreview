import pandas as pd
import sys


aroset = set()
arodata = {}
aroquery = pd.read_csv(sys.argv[2],header=None,sep=' ')
for idx,row in aroquery.iterrows():
    aroset.add(row[0])
    arodata[row[0]] = []

result = open(sys.argv[1],'r')
for line in result:
    line = line.strip()
    row = line.split('\t')
    
    aroid = row[1].split('|')[2]

    preinfo = row[0].split('|')
    if len(preinfo) < 3:
        
        continue
    
   
    if aroid in aroset:
        arodata[aroid].append(line)


for k,v in arodata.items():
    outfile = open(k+'.tab.best','w')
    for line in v:
        outfile.write(line+'\n')
   

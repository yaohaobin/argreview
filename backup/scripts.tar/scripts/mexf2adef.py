from Bio import SeqIO
import sys
seqfile = open(sys.argv[1],'r')
for record in SeqIO.parse(seqfile,'fasta'):
    print('>'+record.id.replace('MexF','adeF').replace('804','777'))
    print(str(record.seq))

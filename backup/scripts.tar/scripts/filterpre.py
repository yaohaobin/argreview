import sys

result = open(sys.argv[1],'r')
curpair = ('','')

for line in result:
    line = line.strip()
    info = line.split('\t')
    pre = info[0]
    aro = info[1]
    if (pre,aro) == curpair:
        continue
    curpair = (pre,aro)
    print(line)

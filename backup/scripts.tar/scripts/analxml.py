from Bio.Blast import NCBIXML
import sys

#anlquery = open(sys.argv[1],'r')
#queryset = {}
cddresult = open(sys.argv[1],'r')
#nolist = {}
#nofile = open(sys.argv[2],'r')

#for name in nofile:
    #name = name.strip()
    #nolist[name] = 1

threshold = {}

threshfile = open(sys.argv[2],'r')

for line in threshfile:
    line = line.strip()
    info = line.split('\t')
    threshold[info[0]] = float(info[2])

xmlparse = NCBIXML.parse(cddresult)
multicdd = 0
num = 0
for record in xmlparse:
        
        '''
        flag = False
        for key in nolist.keys():
            if record.query.find(key) >=0:
                flag = True
                break
        if flag:
            continue
        '''
        num = 0
        if len(record.alignments) > 0:
            for alignment in record.alignments:
                
                for hsp in alignment.hsps:
                    
                    if threshold[alignment.accession] <= float(hsp.bits):
                        num += 1
                        print('>'+record.query+'\t'+alignment.accession+'\t'+str(record.query_length)+'\t'+str(len(hsp.query))+'\t'+str(len(hsp.sbjct))+'\t'+str(hsp.score)+'\t'+str(hsp.bits)+'\t'+str(hsp.expect)+'\t'+str(hsp.identities))
                        print(hsp.match)
                       
                       
            if num>1:
                multicdd += 1


            
                        
        


	    	 	

import pandas as pd
import sys
from sklearn import svm
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import RobustScaler
import numpy as np
import threading
from scipy import stats

def readidx(filename):
    df = pd.read_csv(filename,sep='\t',header=0)
    global aro2name
    for idx,row in df.iterrows():
        aro2name[row[0]] = row[5]
def readdata(filename):
    df = pd.read_csv(filename,sep='\t',header=None)
    data = []
    for idx,row in df.iterrows():
        if len(row[0].split('|')) < 3 :
            continue
            
        preid = row[0].split('|')[0].split(':')[1]
        aroid = row[1].split('|')[2]

        pretype =  row[0].split('|')[2]
        pre2type[preid] = pretype
        preprob[preid] = 0
        prename = row[0].split('|')[1].split(':')[1]
        #pre2name[preid] = prename
        y = row[11]
        x = row[2]
    
        data.append([preid,aroid,x,y])
    return data

def genproblem(data):
    idset = set()
    for preid,aroid,x,y in data:
        if pre2type[preid] != aroid:
            idset.add(preid)
    return idset

def genxy(data,problemid):
    trainx = []
    trainy = []
    trainid = []
    for preid,aroid,x,y in data:
     
        if preid in problemid:
            trainx.append([x,y])
            trainy.append(1)
            trainid.append(preid)
        elif pre2type[preid] != aroid:
            trainx.append([x,y])
            trainy.append(-1)
            trainid.append(preid)
    trainX = np.array(trainx)
    trainY = np.array(trainy)
    return trainX,trainY,trainid

def transform(X):
    scaler=StandardScaler()
    sX = scaler.fit_transform(X)
    return sX


def computesvc(sX,Y):
    svc = svm.SVC(kernel='linear',C=0.01,max_iter=500000,probability=True)
    #sX = transform(X)
    svc.fit(sX,Y)

    if svc.fit_status_ == 0:
        logprob,meanlogprob = calProb(svc,sX,Y)
        #print(logprob,meanlogprob)

    else:
        #print('error')
        return(svc,0,0)
    
   
     
    return svc,logprob,meanlogprob

def recover(data,problemid):



    X,Y,ID = genxy(data,problemid)
    scaler = StandardScaler()
    svc = svm.SVC(kernel='linear',C=1,max_iter=100000,probability=True)
    sX = scaler.fit_transform(X)
    svc.fit(sX,Y)
    w = svc.coef_[0]
    a = -w[0] / w[1]
    xx = np.linspace(np.min(sX), np.max(sX))

    yy = a * xx - (svc.intercept_[0]) / w[1]
 
    x0 = np.array(list(zip(xx,yy)))
    x0 = scaler.inverse_transform(x0)
    lx = x0[:,0]
    ly = x0[:,1]
    slope, intercept, r_value, p_value, std_err = stats.linregress(lx,ly)
    return slope,intercept

def calProb(svc,X,Y):
    logprob = svc.predict_log_proba(X)
    prob = svc.predict_proba(X)
    maxprobability = []
    logprobability = []
    idx = 0
    for a,b in prob:
        y = Y[idx]
        if y == -1:
            logprobability.append(logprob[idx][0])
            maxprobability.append(a)
        else:
            logprobability.append(logprob[idx][1])
            maxprobability.append(b)
        idx = idx + 1
    
    return np.sum(logprobability),np.mean(maxprobability)

def intersectxy(data1,data2,problemid):
    idset1 = set()
    idset2 = set()

    for preid,aroid,x,y in data1:
        if preid in problemid or pre2type[preid] != aroid:            
            idset1.add(preid)
    
    for preid,aroid,x,y in data2:
        if preid in problemid or pre2type[preid] != aroid:
            idset2.add(preid)       
   
    inter = idset1.intersection(idset2)
    
    x1=[]
    x2=[]
    y1=[]
    y2=[]

    leftdata1 =[]

    for preid,aroid,x,y in data1:
        if not preid in inter:
            continue
        
        if preid in problemid:
            leftdata1.append([preid,aroid,x,y])
            x1.append([x,y])
            y1.append(1)
        elif pre2type[preid] != aroid:
            x1.append([x,y])
            y1.append(-1)
            leftdata1.append([preid,aroid,x,y])
         
    X1 = np.array(x1)
    Y1 = np.array(y1)
    
    for preid,aroid,x,y in data2:
        if not preid in inter:
            continue
        if preid in problemid:
            x2.append([x,y])
            y2.append(1)
        elif pre2type[preid] != aroid:
            x2.append([x,y])
            y2.append(-1)

    X2 = np.array(x2)
    Y2 = np.array(y2)
    sX1 = transform(X1)
    sX2= transform(X2)

    return sX1,Y1,sX2,Y2,leftdata1

def recolor(svc,data,X):
    coloring={}
    xx = X[:,0].tolist()
    Y = svc.predict(X).tolist()
    yy = X[:,1].tolist()

    
    for idx in range(len(data)):
        preid,aroid,x,y = data[idx]
        
        if pre2type[preid] == aroid:
            idx = idx + 1
            continue
        w = svc.coef_[0]
        a = -w[0] / w[1]
        #xx = np.linspace(-2, 4)

        y_ = a * xx[i] - (svc.intercept_[0]) / w[1]

        if Y[idx] == 1:
            coloring[preid] = aroid
        idx = idx+ 1
    return coloring

def updateglobe(newtype,prob):
    updatelist = []
    for preid,aroid in newtype.items():
        
        if preprob[preid] == 0 or preprob[preid] < prob:
            pre2type[preid] = aroid
            preprob[preid] = prob
    '''
     for i in range(len(mixlist)):
            preid = mixlist[i][0]
            if mixlist[i][0] == self.aroid:
                truenum += 1
                
                if root is None:
                    root = Node(mixlist[i][2])
                else:
                    insert(root,Node(mixlist[i][2]))
                
                bisect.insort_right(scorelist,mixlist[i][2])
                if mixlist[i][2] < minscore:
                    minscore = mixlist[i][2]
            else:
                
                if not root is None:
                    num = getrank(root,mixlist[i][2])
                    if num>0:
                        ambisum += num
                        ambinum += 1
                

                if mixlist[i][2] > minscore:

                    ambinum += 1
                    #print(mixlist[i])
                    pos = bisect.bisect_right(scorelist,mixlist[i][2])
                    if 0<pos and pos<=len(scorelist):
                        ambisum += pos
      '''


class processpair (threading.Thread):
    def __init__(self,queryname,querybestname):
        threading.Thread.__init__(self)
        #self.reference = reference
        self.queryname = queryname
        self.querybestname = querybestname
        self.query = []
        self.querybest = []
    def run(self):
        global pre2data
        global pre2best
        global ygene
        global ngene
        global l1
        global l2
        global l3
        global ct
        aroid = self.queryname.split('.')[0]
        self.query = pre2data[aroid]
        self.querybest = readdata(self.querybestname)
        problemid = genproblem(self.querybest)
        #print('read finish')
        X1,Y1,X2,Y2,queryleft=intersectxy(self.query,adef,problemid)
       
        global fn1
        
       
               
        
        


        qsvc,logprobq,meanprobq = computesvc(X1,Y1)
        rsvc,logprobr,meanprobr = computesvc(X2,Y2)
        newtype = {}
        #print('svc finish')
        threadLock.acquire()
        print(aro2name[aroid],'alternative probility:',logprobq,'original probability:',logprobr)
        if logprobq != 0 and logprobq> logprobr:
            
            newtype=recolor(qsvc,queryleft,X1)
            slope,intercept = recover(self.query,problemid)            
            print(aro2name[aroid],'Slope and intercept after recoloring:',slope,intercept)
        w = qsvc.coef_[0]
        a = -w[0] / w[1]
        #xx = np.linspace(-2, 4)

        b =  - (qsvc.intercept_[0]) / w[1]
        #print(aro2name[aroid],a,b,logprobq,logprobr,meanprobq,meanprobr)
        oldfp = calFP(self.query,aroid)
        oldfn = calC(self.querybest)
        if len(newtype)>0:

            
            fn1 += oldfn
            #ygene.append(aro2name[aroid])
            
            #print('update ',len(newtype))
            updateglobe(newtype,meanprobq) 
            L1,L2,L = calL(pre2data,pre2best) 
            l1.append(L1)
            l2.append(L2)
            l3.append(L)
            #u=ict.append(fntax(pre2data))
            newfp = calFP(self.query,aroid)
            newfn = calC(self.querybest) 
            #fp2 += newfp
            #fn2 += newfn
            #print(calC(self.querybest))
        #else:
           #ngene.append(aro2name[aroid])
        threadLock.release()

def readtax(filename):
    global pre2tax
    tax = open(filename,'r') 
    for line in tax:
        line = line.strip()
        row = line.split('\t')
        if len(row[0].split('|')) < 3 :
            continue

        preid = row[0].split('|')[0].split(':')[1]
        taxid = row[1]
        
        pre2tax[preid] = taxid

def gentaxfamily(data):
    global pre2tax
    taxfamily = {}
    for preid,aroid,x,y in data:
        if not preid in pre2tax.keys():
            continue
        taxid = pre2tax[preid] 
        if taxid in taxfamily.keys():
            taxfamily[taxid].append([preid,aroid,x,y])
        else:
            taxfamily[taxid] = [[preid,aroid,x,y]]
    return taxfamily 


def calL(family,familybest):
    global adef
    global adefbest
    global adefid
    
    fn = calFP(adef,adefid)
    
    C = calC(adefbest)
    
    L1 = type2weight[adefid]*1.0/len(adef)*fn 
    L2 = C
    for aroid,data in family.items():
        
        fn = calFP(data,aroid)
        weight = type2weight[aroid]*1.0/len(adef)
        L1 += fn*weight
 
        databest = familybest[aroid]
        C = calC(databest)
        L2 += C
    return L1,L2,L2-L1

def calallFP(family):
    fp = 0
    global adef
    for aroid,data in family.items():
        fp+= calFP(data,aroid)*type2weight[aroid]*1.0/len(adef)
    return fp

def calFP(data,name):
    global type2weight
    minscore = 10000
    
    datasorted = sorted(data,key=lambda d:d[2])
    fn = 0.0
    weight = 0
    for preid,aroid,x,y in datasorted:
        if pre2type[preid] == aroid:
            weight += 1
            if y < minscore:
                minscore = y
        elif y>minscore:
            fn += 1
    type2weight[name] = weight
    return fn/len(data)
          
def fntax(pre2data):
    ctax = 0
    adeftax = gentaxfamily(adef)
    ctax+= calallFP(adeftax)
    for aroid,data in pre2data.items():
        datatax = gentaxfamily(data)
        ctax += calallFP(datatax)
    return ctax

def calC(databest):
    num = 0
    for preid,aroid,x,y in databest:
        if pre2type[preid] == aroid:
            num += 1
    return num*1.0/totallen

def calallC(family):
    C = 0
    for aroid,databest in family.items():
        C += calC(databest)
    return C
    
def readquerylist(filename):
    filenames = []
    
    query = pd.read_csv(filename,header=None,sep=' ')
    for idx,row in query.iterrows():
        name = row[0]+'.tab'
        bestname = name+'.best'
        filenames.append([name,bestname])
    return filenames

pre2type = {}
preprob = {}
pre2tax = {}
pre2best = {}
pre2data = {}
type2weight = {}
totallen = 0
print("usage: computesvc.py adef familylist threadnum adefleft aroidx ")
adef = readdata(sys.argv[1])
adefbest = readdata(sys.argv[1]+'.best')
adefid= 'ARO:3000777'
totallen += len(adefbest)
querylist = readquerylist(sys.argv[2])
aro2name = {}
readidx(sys.argv[5])
#ctax =0

ygene = []
ngene = []
l1 = []
l2 = []
l3 = []
ct = []
for queryname,querybestname in querylist:
    aroid = queryname.split('.')[0]
    pre2data[aroid] = readdata(queryname)
    pre2best[aroid] = readdata(querybestname)
    totallen+=len(pre2best[aroid])

print('start',calFP(adef,adefid))


fn1 = calFP(adef,adefid)
fn1 += calallFP(pre2data)
fp2 = 0
C1 = calC(adefbest)
C1 += calallC(pre2best)
print('L value:',C1-fn1)
'''
print('intial L: ',calL(pre2data,pre2best)) 
print('initial fn ',fn1,C1)

readtax(sys.argv[4])
taxfamily = gentaxfamily(adef)

ctax = 0
adeftax = genfamily(adef)
ctax+= calallFP(adeftax)
for aroid,data in pre2data.items():
    datatax = gentaxfamily(data)
    ctax += calallFP(datatax)
print(ctax)
ct.append(ctax)

print('tax fn',calFP(adef),calallFP(taxfamily))
'''

threadLock = threading.Lock()
threadnum = int(sys.argv[3])
i = 0

while i<len(querylist):
     threads  = []
     for j in range(threadnum):
         filename = querylist[i][0]
         bestname = querylist[i][1]

         if True:
             #print(aroid)

             arothread = processpair(filename,bestname)
             arothread.start()
             threads.append(arothread)


         i += 1
         if i>= len(querylist):
             break


     for t in threads:
         t.join()
print('end')
'''
print(ygene)
print(ngene)
print(l1)
print(l2)
print(l3)
print(ct)
'''
fn2 = calFP(adef,adefid)
fn2 += calallFP(pre2data)
C2 = calC(adefbest)
C2 += calallC(pre2best)


print('L value:',C2-fn2)
'''
ctax = 0
adeftax = gentaxfamily(adef)
ctax += calallFP(adeftax)
for aroid,data in pre2data.items():
    datatax = gentaxfamily(data)
    ctax += calallFP(datatax)
print(ctax)
'''


adefleft = open(sys.argv[4],'w')
for preid,aroid,x,y in adef:
    if pre2type[preid] == aroid:
        adefleft.write(str(preid)+'\t'+str(x)+'\t'+str(y)+'\n')


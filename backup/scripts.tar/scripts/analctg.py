import sys

drughit = {}
genehit = {}

ctgresult = open(sys.argv[1],'r')
for line in ctgresult:
    line = line.strip()
    info = line.split('\t')
    gene = info[0]
    drug = info[7].split(' ')[0]
    if drug.find('Warning')>=0:
        print(line)
    if drug in drughit.keys():
        drughit[drug] += 1
    else:
        drughit[drug] = 1

drughitlist = []

for k,v in drughit.items():
    drughitlist.append((k,v))

drughitlist = sorted(drughitlist,key=lambda x:x[1],reverse=True)

print(drughitlist)

aro2drug = {}
drug2res = {}
aroindex = open(sys.argv[2],'r')
next(aroindex)
for line in aroindex:
    line = line.strip()
    info = line.split('\n')
    prot2drug[info[0]] = info[3]
    drug = info[3]
    if drug in drug2res.keys():
        prot2drug[info[0]] = drug2res[drug]
    else:
        if 





import sys
import pandas as pd

card2amrseq = {}

card2amr = pd.read_csv(sys.argv[1],header=None,sep='\t')
for idx,row in card2amr.iterrows():
    cardid = row[0].split('|')[2]
    amrid = row[1]
    if not cardid in card2amrseq.keys():
        card2amrseq[cardid] = amrid



amrseq2hmm = {}
amr2hmm = pd.read_csv(sys.argv[2],header=None,sep=' ')
for idx,row in amr2hmm.iterrows():
    #print(row[0],row[2])
    amrseq2hmm[row[0]] = row[2]

for cardid,amrseq in card2amrseq.items():
    print(cardid+'\t'+amrseq2hmm[amrseq])

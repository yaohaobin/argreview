import sys
import os

for dirname,pathnames,filenames in os.walk(sys.argv[1]):
    for filename in filenames:
       
        if filename.find('txt.orf')<0 or filename.find('RR')<0:
            continue
        resultfile = open(dirname+'/'+filename,'r')
        for line in resultfile:
            line = line.strip()
            print(line+'\t'+filename)

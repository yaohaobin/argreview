import pysam
import sys

samfile = pysam.AlignmentFile(sys.argv[1])

for alignment in samfile:
    if alignment.is_unmapped or alignment.is_secondary or alignment.is_supplementary:
        continue
    ap = alignment.get_aligned_pairs(with_seq=True,matches_only=True)
    num = 0
    for (q,r,c) in ap:
        if c.isupper():
            num = num + 1
    print(alignment.query_name+'\t'+alignment.reference_name+'\t'+str(alignment.alen)+'\t'+str(num)+'\t'+str(alignment.query_length))

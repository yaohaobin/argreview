import pandas as pd
import sys

result = open(sys.argv[1],'r')

best={}
query = sys.argv[2].lower()
for line in result:
    line = line.strip()
    info = line.split('\t')
    aro = info[1]
    orf = info[0]
    if not orf in best.keys():
        best[orf] = aro
        if aro.lower().find(query)>=0:
            print(line)

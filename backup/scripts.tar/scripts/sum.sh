for i in `ls result`
do
  python sum.py result/$i > result/$i/result.tab
done

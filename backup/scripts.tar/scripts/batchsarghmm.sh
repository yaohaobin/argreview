for i in `cat $1`
do
  input=$(basename $i) 
  hmmsearch -E 1e-10 -o sample2sarghmm/$input.hmm --tblout  sample2sarghmm/$input.hmm.tab --cpu 48 sarg.hmm $i
done
